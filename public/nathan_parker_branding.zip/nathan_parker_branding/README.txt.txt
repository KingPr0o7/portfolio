Nathan Parker - Logos and Standalone Pictogram
-------------------------------------------------

Last Updated: July 24, 2024
Trademark Status: Pending

These logos are to represent Nathan Parker software, websites, and experiences.
Follow the branding guidelines at: https://www.ncp.dev/branding/

If you fail to follow all these guidelines, you'll be contacted via legal@ncp.dev
or physically mailed a cease-and-desist letter.  

Need additional information or request permission for something? Email: legal@ncp.dev

Thank you, and please follow the guidelines!

© 2024 Nathan Parker. Trademark pending. All rights reserved.